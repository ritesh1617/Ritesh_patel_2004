#include <stdio.h>

main()
 {
    char character;

    printf("Enter a character: ");
    scanf(" %c", &character);  

    printf("ASCII value of '%c' is: %d\n", character, character);

}

