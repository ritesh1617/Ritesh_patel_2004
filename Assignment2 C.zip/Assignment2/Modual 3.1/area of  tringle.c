#include<stdio.h>
main()
{
	int b,h,a;
	printf("enter first value:");
	scanf("%d",&b);
	
	printf("enter second value:");
	scanf("%d",&h);
	
	a=b*h/2;
	printf("area is:%d",a);
	
	
}
