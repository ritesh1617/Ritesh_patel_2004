#include<stdio.h>
 main()
{
	int l,w,a;
	printf("enter first value:");
	scanf("%d",&l);
	
	printf("enter second value:");
	scanf("%d",&w);
	
	a=l*w;
	printf("Area is: %d square units\n", a);

	
}
