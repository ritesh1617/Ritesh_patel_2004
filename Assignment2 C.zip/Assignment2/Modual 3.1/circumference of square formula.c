#include<stdio.h>

 main() {
    float a, circumference;

    printf("Enter the side length of the square: ");
    scanf("%f", &a);

    circumference = 4 * a;

    printf("Circumference of the square is: %.2f units\n", circumference);

}

