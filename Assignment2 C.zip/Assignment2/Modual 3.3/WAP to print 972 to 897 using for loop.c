#include <stdio.h>

main() 
{
	int i;
	
    // Using a for loop to print numbers from 972 to 897
    for ( i = 972; i >= 897; i--)
	 {
        printf("%d ", i);
    }

    return 0;
}

